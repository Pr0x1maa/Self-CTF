<?php
error_reporting(0); 

#被你找到了:(
#给你准备了一份小礼物放在了gift.php中了哦~

function check($key){
    $blacklist = [
        'file', 'phar', 'zip', 'data', 'glob', 'expect', 'ftp',
        'etc', 'proc',
        'base64',  'string',  'rot13', 'quoted', 'zlib', 'input', 'ter/res',
        'eval', 'system', 'exec', 'shell_exec', 'popen', 'passthru', 'echo'
    ];

    foreach ($blacklist as $keyword){
        if (stripos($key, $keyword) !== false){
            return false;
        }
    }
    return true;
}

$file = $_POST['file'];

if (filter_var($file, FILTER_VALIDATE_URL)){

    if (check($file)){
        $content = @file_get_contents($file);
        echo $content;
    }else{
        echo "waf!!!";
    }
}else{
    echo "无效的url格式";
}
?>