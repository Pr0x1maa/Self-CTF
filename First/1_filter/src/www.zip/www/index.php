<?php
error_reporting(0); 

#被你找到了:(
#flag in /flag

function check($key){
    $blacklist = [
        'file', 'phar', 'zip', 'data', 'glob', 'expect', 'ftp',
        'passwd', 'shadow', 'etc',
        'base64',  'string',  'rot13', 
        'eval', 'system', 'exec', 'shell_exec', 'popen', 'passthru', 'echo'
    ];

    foreach ($blacklist as $keyword){
        if (stripos($key, $keyword) !== false){
            return false;
        }
    }
    return true;
}

$file = $_POST['file'];

if (filter_var($file, FILTER_VALIDATE_URL)){

    if (check($file)){
        $content = @file_get_contents($file);
        //不可以直接读哦~
        if (stripos($content, 'sdpcsec{') !== false){
            echo "waf!!!";
        }else{
            echo $content;
        }
    }else{
        echo "waf!!!";
    }
}else{
    echo "无效的url格式";
}
?>